ansible-playbook -v -b -i /dev/null site.yml
